package project.bfour.debtormaintenance;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DebtorMaintenanceApplication {

    public static void main(String[] args) {
        SpringApplication.run(DebtorMaintenanceApplication.class, args);
    }

}
