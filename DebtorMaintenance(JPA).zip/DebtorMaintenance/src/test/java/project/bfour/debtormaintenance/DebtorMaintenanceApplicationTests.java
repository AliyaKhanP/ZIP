package project.bfour.debtormaintenance;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DebtorMaintenanceApplicationTests {

    @Test
    void contextLoads() {
    }

}
