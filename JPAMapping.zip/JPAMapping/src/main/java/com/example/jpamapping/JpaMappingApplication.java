package com.example.jpamapping;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JpaMappingApplication {

    public static void main (String[] args) {
       SpringApplication.run(JpaMappingApplication.class, args);

    }

}
