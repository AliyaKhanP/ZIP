package com.example.jpamapping.model;

import org.springframework.stereotype.Component;

import javax.persistence.*;

@Component
@Entity
@Table(name = "laptop")
public class Laptop {

    @Id
    private int id;
    private String model;

    @OneToOne(mappedBy = "laptop")
    private Student student;

    public Laptop () {
    }

    public int getId () {
        return id;
    }

    public void setId (int id) {
        this.id = id;
    }

    public String getModel () {
        return model;
    }

    public void setModel (String model) {
        this.model = model;
    }

    public Student getStudent () {
        return student;
    }

    public void setStudent (Student student) {
        this.student = student;
    }
}
