package com.example.jpamapping.controller;

import com.example.jpamapping.model.Student;
import com.example.jpamapping.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class StudentController {

    @Autowired
    StudentRepository studentRepository;

    @RequestMapping("/")
    public String index(Model model) {
        model.addAttribute("student", new Student());
        return "index.jsp";
    }

    @RequestMapping("/save")
    public String save(Student student) {
        studentRepository.save(student);
        System.out.println("Saved");
        return "success.jsp";
    }


}
